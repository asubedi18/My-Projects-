var guessWords = ["GUEST", "POLAR", "LOOSE", "BREAK", "FACES"];
var goal = guessWords[Math.floor(Math.random() * guessWords.length)]; 
var goal1 = goal[0], goal2 = goal[1], goal3 = goal[2], goal4 = goal[3], goal5 = goal[4];
var turn = 1;
var letter1, letter2, letter3, letter4, letter5;
var colors = ["gray", "gray", "gray", "gray", "gray"];

enableRow(turn);

function enableRow(turn) {
    for (var i = 1; i <= 5; i++) {
        var input = document.getElementById(`r${turn}l${i}`);
        input.disabled = false;
        input.addEventListener("input", handleInput);
        input.addEventListener("keydown", handleBackspace);
    }
    document.getElementById(`r${turn}l1`).focus();
}

function handleInput(event) {
    var input = event.target;
    var value = input.value.toUpperCase();
    input.value = value;
    moveNext(input);
}

function handleBackspace(event) {
    if (event.key === "Backspace" && !event.target.value) {
        movePrevious(event.target); 
    }
}

function moveNext(input) {
    var row = parseInt(input.id.charAt(1));
    var col = parseInt(input.id.charAt(3));
    if (col < 5) {
        document.getElementById(`r${row}l${col + 1}`).focus();
    }
}

function movePrevious(input) {
    var row = parseInt(input.id.charAt(1));
    var col = parseInt(input.id.charAt(3));
    if (col > 1) {
        document.getElementById(`r${row}l${col - 1}`).focus();
    }
}

function takeTurn() {
    if (turn == 1) {
        letter1 = document.getElementById("r1l1").value.toUpperCase();
        letter2 = document.getElementById("r1l2").value.toUpperCase();
        letter3 = document.getElementById("r1l3").value.toUpperCase();
        letter4 = document.getElementById("r1l4").value.toUpperCase();
        letter5 = document.getElementById("r1l5").value.toUpperCase();
    } else if (turn == 2) {
        letter1 = document.getElementById("r2l1").value.toUpperCase();
        letter2 = document.getElementById("r2l2").value.toUpperCase();
        letter3 = document.getElementById("r2l3").value.toUpperCase();
        letter4 = document.getElementById("r2l4").value.toUpperCase();
        letter5 = document.getElementById("r2l5").value.toUpperCase();
    } else if (turn == 3) {
        letter1 = document.getElementById("r3l1").value.toUpperCase();
        letter2 = document.getElementById("r3l2").value.toUpperCase();
        letter3 = document.getElementById("r3l3").value.toUpperCase();
        letter4 = document.getElementById("r3l4").value.toUpperCase();
        letter5 = document.getElementById("r3l5").value.toUpperCase();
    } else if (turn == 4) {
        letter1 = document.getElementById("r4l1").value.toUpperCase();
        letter2 = document.getElementById("r4l2").value.toUpperCase();
        letter3 = document.getElementById("r4l3").value.toUpperCase();
        letter4 = document.getElementById("r4l4").value.toUpperCase();
        letter5 = document.getElementById("r4l5").value.toUpperCase();
    } else if (turn == 5) {
        letter1 = document.getElementById("r5l1").value.toUpperCase();
        letter2 = document.getElementById("r5l2").value.toUpperCase();
        letter3 = document.getElementById("r5l3").value.toUpperCase();
        letter4 = document.getElementById("r5l4").value.toUpperCase();
        letter5 = document.getElementById("r5l5").value.toUpperCase();
    } else if(turn == 6) {
        letter1 = document.getElementById("r6l1").value.toUpperCase();
        letter2 = document.getElementById("r6l2").value.toUpperCase();
        letter3 = document.getElementById("r6l3").value.toUpperCase();
        letter4 = document.getElementById("r6l4").value.toUpperCase();
        letter5 = document.getElementById("r6l5").value.toUpperCase();
    }

    
    var guessWord = letter1 + letter2 + letter3 + letter4 + letter5;
    if (!guessWords.includes(guessWord)) {
        document.getElementById("result").innerHTML = "Not in the word list!";
        return; 
    }

    checkGame();

    if (turn < 6) {
        turn++;
        enableRow(turn);
    }
}

function checkGame() {
    var goalWord = [goal1, goal2, goal3, goal4, goal5];
    var guessWord = [letter1, letter2, letter3, letter4, letter5];
    colors = ["gray", "gray", "gray", "gray", "gray"]; 

    for (var i = 0; i < 5; i++) {
        if (goalWord[i] === guessWord[i]) {
            colors[i] = "green";
            document.getElementById(`r${turn}l${i + 1}`).style.backgroundColor = "green";
        } else {
            for (var j = 0; j < 5; j++) {
                if (guessWord[i] === goalWord[j] && colors[i] !== "green") {
                    colors[i] = "yellow";
                    document.getElementById(`r${turn}l${i + 1}`).style.backgroundColor = "yellow";
                }
            }
        }

        if (colors[i] === "gray") {
            document.getElementById(`r${turn}l${i + 1}`).style.backgroundColor = "gray";
        }
    }

    if (turn > 6) {
        document.getElementById("result").innerHTML = "No more turns!";
    } else if (colors.every((color) => color === "green")) {
        document.getElementById("result").innerHTML = "You win!";
        disableAllInputs();
    } else if (turn === 6) {
        document.getElementById("result").innerHTML = `You lose! The word was: ${goal}`;
    }
}

function disableAllInputs() {
    for (var r = 1; r <= 6; r++) {
        for (var c = 1; c <= 5; c++) {
            document.getElementById(`r${r}l${c}`).disabled = true;
        }
    }
}
